import http from '.';

export const getCampList = body => http.get('camp');