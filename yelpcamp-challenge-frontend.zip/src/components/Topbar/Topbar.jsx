import React from 'react';
import { ArrowBack } from '@material-ui/icons';
import { ReactComponent as Logo } from '../../assets/images/Logo.svg';
import "./Topbar.scss";

const Topbar = ({ isBack = true }) => {
    return (
        <div className="topbar">
            <div className="topbar__left">
                <Logo className="topbar__logo" />
                <div className="topbar__home">
                    Home
                </div>
            </div>
            {
                isBack && (<div className="topbar__back">
                    <ArrowBack className="topbar__backIcon" />
                    <p className="topbar__backText">Back to campgrounds</p>
                </div>)
            }
            <div className="topbar__right">
                <div className="topbar__userName">johndoe</div>
                <div className="topbar__logout">logout</div>
            </div>
        </div>
    )
}

export default Topbar
