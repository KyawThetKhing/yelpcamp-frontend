import AIRBNB from '../assets/images/Airbnb.svg';
import BOOKING from '../assets/images/Booking.svg';
import CHAT_BUBBULE from '../assets/images/Chat Bubble.svg';
import CHECK_MARK from '../assets/images/Checkmark.svg';
import CLOSE from '../assets/images/Close.svg';
import HAMBURGER_MENU from '../assets/images/Hamburger Menu.svg';
import { ReactComponent as LOGO } from '../assets/images/Logo.svg';

export const IMG = [
    AIRBNB,
    BOOKING,
    CHAT_BUBBULE,
    CHECK_MARK,
    CLOSE,
    HAMBURGER_MENU,
    LOGO
]