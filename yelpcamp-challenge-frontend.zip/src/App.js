import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect
} from "react-router-dom";
import LoginPage from './pages/LoginPage';
import OverviewPage from './pages/OverviewPage';
import CampPage from './pages/CampPage';

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          {/* <Route path="/" >
            <Redirect to="login" />
          </Route> */}
          <Route path="/login" >
            <LoginPage />
          </Route>
          <Route path="/overview" >
            <OverviewPage />
          </Route>
          <Route path="/camp" >
            <CampPage />
          </Route>
          {/* <Route path="/register">
          <RegisterPage />
        </Route>
        <Route path="/">
          <Home />
        </Route> */}
        </Switch>
      </Router>
    </div>
  );
}

export default App;
