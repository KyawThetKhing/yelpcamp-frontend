import CampPage from "./CampPage";

export default CampPage;